from django.contrib import admin
from .models import SignupForm

admin.site.register(SignupForm)